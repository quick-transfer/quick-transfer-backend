package com.weg.quicktransfer.dto.user;

import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record UserRequestDTO(
    @NotBlank
    String name,
    @NotBlank
    String userName,
    @NotBlank
    @Email
    String email,
    @NotBlank
    @Length(min = 14)
    String password
) {
}
