package com.weg.quicktransfer.dto.student;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record StudentRequestDTO(
    @NotBlank
    String name,
    @NotBlank
    String email,
    @NotNull
    @Positive
    Double averageGrade,
    @NotNull
    @Positive
    Long classId,
    @NotBlank
    String statusStudent,
    Boolean hasSeenEmail,
    @NotNull
    @Positive
    Long interviewId
) {
}
